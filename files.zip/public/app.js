const term = new Terminal({ cursorBlink: true });
const fitAddon = {
  fit: () => {
    // very small fit: compute cols/rows using char size (quick prototype hack)
    // For production use xterm-addon-fit
  }
};
term.open(document.getElementById('term'));

const ws = new WebSocket((location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host);
ws.onopen = () => {
  console.log('ws open');
};
ws.onmessage = (ev) => {
  try {
    const msg = JSON.parse(ev.data);
    if (msg.type === 'output') term.write(msg.data);
  } catch(e) {
    // ignore
  }
};

term.onData(data => {
  ws.send(JSON.stringify({ type: 'input', data }));
});

// Resize handling (very simple)
function sendResize() {
  const cols = term.cols || 80;
  const rows = term.rows || 24;
  ws.send(JSON.stringify({ type: 'resize', cols, rows }));
}
window.addEventListener('resize', sendResize);

// Toolbar buttons to send sequences
document.getElementById('btn-esc').addEventListener('click', () => ws.send(JSON.stringify({ type:'input', data:'\x1b' })));
document.getElementById('btn-tab').addEventListener('click', () => ws.send(JSON.stringify({ type:'input', data:'\t' })));
document.getElementById('btn-^C').addEventListener('click', () => ws.send(JSON.stringify({ type:'input', data:'\x03' })));
document.getElementById('btn-paste').addEventListener('click', async () => {
  const text = await navigator.clipboard.readText().catch(()=> '');
  if (text) ws.send(JSON.stringify({ type:'input', data:text }));
});

// Quick commands
document.querySelectorAll('.cmd').forEach(b => {
  b.addEventListener('click', () => {
    const c = b.getAttribute('data-cmd') + '\n';
    ws.send(JSON.stringify({ type:'input', data:c }));
  });
});